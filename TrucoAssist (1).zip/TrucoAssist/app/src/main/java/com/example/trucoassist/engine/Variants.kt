package com.example.trucoassist.engine

/** Cada variante define a força das cartas. Manilhas têm power >= 100. */
interface TrucoVariant {
    val displayName: String
    fun power(card: Card, vira: Card?): Int
    fun isManilha(card: Card, vira: Card?): Boolean = power(card, vira) >= 100
    /** 0..3 (fraca..zap) quando for manilha. */
    fun manilhaIndex(card: Card, vira: Card?): Int = power(card, vira) - 100
}

/** Paulista: manilha = carta seguinte à vira; empate entre manilhas pelo naipe. */
object Paulista : TrucoVariant {
    override val displayName = "Truco Paulista"
    fun manilhaRank(vira: Card): Rank = Rank.entries[(vira.rank.ordinal + 1) % Rank.entries.size]
    override fun power(card: Card, vira: Card?): Int =
        if (vira != null && card.rank == manilhaRank(vira)) 100 + card.suit.ordinal else card.rank.ordinal
}

/** Mineiro: manilhas fixas (7♦ < A♠ < 7♥ < 4♣ "zap"), sem vira. */
object Mineiro : TrucoVariant {
    override val displayName = "Truco Mineiro"
    private val fixed = listOf(
        Card(Rank.SETE, Suit.OUROS), Card(Rank.AS, Suit.ESPADAS),
        Card(Rank.SETE, Suit.COPAS), Card(Rank.QUATRO, Suit.PAUS),
    )
    override fun power(card: Card, vira: Card?): Int {
        val i = fixed.indexOf(card)
        return if (i >= 0) 100 + i else card.rank.ordinal
    }
}

object Variants {
    fun byName(name: String): TrucoVariant = if (name == "MINEIRO") Mineiro else Paulista
}
