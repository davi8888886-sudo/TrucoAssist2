package com.example.trucoassist.engine

/**
 * Heurísticas simples (MVP). Não calcula probabilidades: sugere a carta e se vale pedir/aceitar truco.
 * [trucoThreshold] é ajustável pelo usuário.
 */
class TrucoEngine(private val variant: TrucoVariant, private val trucoThreshold: Int = 8) {

    /** Pontos: manilha 4..7, 3 = 3, 2 = 2, A = 1. */
    fun handStrength(hand: List<Card>, vira: Card?): Int = hand.sumOf { c ->
        when {
            variant.isManilha(c, vira) -> 4 + variant.manilhaIndex(c, vira)
            c.rank == Rank.TRES -> 3
            c.rank == Rank.DOIS -> 2
            c.rank == Rank.AS -> 1
            else -> 0
        }
    }

    fun suggest(s: GameState): Suggestion {
        if (s.hand.isEmpty()) return Suggestion(null, null, "Nenhuma carta na mão.")
        val sorted = s.hand.sortedBy { variant.power(it, s.vira) }
        val strength = handStrength(s.hand, s.vira)
        val (card, why) = chooseCard(sorted, s)
        val answer = if (s.trucoCalled) answerTruco(strength, s) else null
        return Suggestion(card, trucoAdvice(strength), why, answer)
    }

    /** Responde ao truco do adversário. Mínimo = limiar-3; mais folgado se já ganhou uma rodada, mais rígido se perdeu. */
    private fun answerTruco(strength: Int, s: GameState): String {
        var need = trucoThreshold - 3
        if (s.roundsWon > 0) need -= 2
        if (s.roundsLost > 0) need += 1
        return if (strength >= need) "SIM ✅ — aceite o truco (força $strength, mínimo $need)"
        else "NÃO ❌ — corra (força $strength, mínimo $need)"
    }

    private fun chooseCard(sorted: List<Card>, s: GameState): Pair<Card, String> {
        val p = { c: Card -> variant.power(c, s.vira) }
        s.table?.let { t ->
            sorted.firstOrNull { p(it) > p(t) }?.let { return it to "Menor carta que vence ${t}." }
            sorted.firstOrNull { p(it) == p(t) }?.let { return it to "Empata com ${t} (o restante decide)." }
            return sorted.first() to "Nenhuma carta vence ${t}: descarte a mais fraca."
        }
        if (sorted.size == 1) return sorted.first() to "Última carta."
        if (s.roundNumber == 1 && sorted.size >= 3)
            return sorted[sorted.size / 2] to "Abra com a carta do meio e guarde a mais forte."
        return sorted.last() to
            if (s.roundsWon > 0) "Já ganhou uma: feche com a mais forte." else "Precisa ganhar: jogue a mais forte."
    }

    private fun trucoAdvice(strength: Int): String = when {
        strength >= trucoThreshold -> "Mão forte ($strength): considere pedir TRUCO; aceite se pedirem."
        strength >= trucoThreshold - 3 -> "Mão média ($strength): aceite se pedirem; evite pedir."
        else -> "Mão fraca ($strength): evite pedir; considere correr se pedirem."
    }
}

fun formatReport(hand: List<Card>, vira: Card?, table: Card?, s: Suggestion, note: String? = null): String =
    buildString {
        s.trucoAnswer?.let { append("TRUCO: ").append(it).append('\n') }
        append("Mão: ").append(hand.joinToString(" ")).append('\n')
        vira?.let { append("Vira: ").append(it).append('\n') }
        table?.let { append("Mesa: ").append(it).append('\n') }
        append("Jogar: ").append(s.card ?: "—").append(" — ").append(s.explanation)
        s.trucoAdvice?.let { append('\n').append(it) }
        note?.let { append('\n').append(it) }
    }
