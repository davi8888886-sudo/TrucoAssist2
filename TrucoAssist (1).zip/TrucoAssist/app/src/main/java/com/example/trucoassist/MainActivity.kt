package com.example.trucoassist

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.trucoassist.capture.CaptureService
import com.example.trucoassist.databinding.ActivityMainBinding
import com.example.trucoassist.engine.CardParser
import com.example.trucoassist.engine.GameState
import com.example.trucoassist.engine.TrucoEngine
import com.example.trucoassist.engine.Variants
import com.example.trucoassist.engine.formatReport

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private val variantKeys = listOf("PAULISTA", "MINEIRO")

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
            } else toast("Captura não autorizada.")
            b.root.postDelayed({ refresh() }, 700)
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { launchProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = Prefs(this)

        b.spVariant.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            variantKeys.map { Variants.byName(it).displayName })
        b.spVariant.setSelection(variantKeys.indexOf(prefs.variant).coerceAtLeast(0))
        b.swOverlay.isChecked = prefs.overlayEnabled
        b.etHand.setText(prefs.manualHand); b.etVira.setText(prefs.manualVira); b.etTable.setText(prefs.manualTable)
        b.etRound.setText(prefs.round.toString()); b.etWon.setText(prefs.roundsWon.toString())
        b.etLost.setText(prefs.roundsLost.toString())
        b.etRoiHand.setText(prefs.roiHand); b.etRoiVira.setText(prefs.roiVira); b.etRoiTable.setText(prefs.roiTable)
        b.etThreshold.setText(prefs.trucoThreshold.toString())

        b.btnToggle.setOnClickListener { toggle() }
        b.btnSave.setOnClickListener { save(); toast("Configurações salvas.") }
        b.btnManual.setOnClickListener { save(); manualSuggest(false) }
        b.btnManualTruco.setOnClickListener { save(); manualSuggest(true) }
        b.swOverlay.setOnCheckedChangeListener { _, on -> prefs.overlayEnabled = on; if (on) ensureOverlayPerm() }
        b.btnOverlayPerm.setOnClickListener { openOverlaySettings() }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        if (CaptureService.running) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            b.root.postDelayed({ refresh() }, 500)
            return
        }
        save()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else launchProjection()
    }

    private fun launchProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent()) // consentimento explícito do Android
    }

    private fun ensureOverlayPerm() { if (!Settings.canDrawOverlays(this)) openOverlaySettings() }

    private fun openOverlaySettings() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun save() {
        prefs.variant = variantKeys[b.spVariant.selectedItemPosition]
        prefs.manualHand = b.etHand.text.toString(); prefs.manualVira = b.etVira.text.toString()
        prefs.manualTable = b.etTable.text.toString()
        prefs.round = b.etRound.text.toString().toIntOrNull()?.coerceIn(1, 3) ?: 1
        prefs.roundsWon = b.etWon.text.toString().toIntOrNull() ?: 0
        prefs.roundsLost = b.etLost.text.toString().toIntOrNull() ?: 0
        prefs.roiHand = b.etRoiHand.text.toString(); prefs.roiVira = b.etRoiVira.text.toString()
        prefs.roiTable = b.etRoiTable.text.toString()
        prefs.trucoThreshold = b.etThreshold.text.toString().toIntOrNull() ?: 8
    }

    private fun manualSuggest(trucoCalled: Boolean) {
        val hand = CardParser.parse(prefs.manualHand)
        if (hand.isEmpty()) { b.tvResult.text = "Informe sua mão, ex.: 3P 2C AE"; return }
        val vira = CardParser.parse(prefs.manualVira).firstOrNull()
        val table = CardParser.parse(prefs.manualTable).firstOrNull()
        val s = TrucoEngine(Variants.byName(prefs.variant), prefs.trucoThreshold)
            .suggest(GameState(hand, vira, table, prefs.round, prefs.roundsWon, prefs.roundsLost, trucoCalled))
        b.tvResult.text = formatReport(hand, vira, table, s)
    }

    private fun refresh() {
        val running = CaptureService.running
        b.btnToggle.text = if (running) "Parar captura" else "Iniciar captura"
        b.tvStatus.text = "Captura: ${if (running) "ativa" else "parada"} • Sobreposição: " +
            if (Settings.canDrawOverlays(this)) "permitida" else "sem permissão"
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
