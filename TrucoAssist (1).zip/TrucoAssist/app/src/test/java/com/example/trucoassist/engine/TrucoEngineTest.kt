package com.example.trucoassist.engine

import org.junit.Assert.*
import org.junit.Test

class TrucoEngineTest {
    private fun c(s: String) = CardParser.parse(s).single()

    @Test fun paulistaManilhaIsNextRankAndWraps() {
        assertEquals(Rank.DAMA, Paulista.manilhaRank(c("7C")))
        assertEquals(Rank.QUATRO, Paulista.manilhaRank(c("3O")))
        assertTrue(Paulista.power(c("QO"), c("7C")) > Paulista.power(c("3P"), c("7C")))
        assertTrue(Paulista.power(c("QP"), c("7C")) > Paulista.power(c("QC"), c("7C")))
    }

    @Test fun mineiroFixedManilhas() {
        assertTrue(Mineiro.power(c("4P"), null) > Mineiro.power(c("7C"), null))
        assertTrue(Mineiro.power(c("7C"), null) > Mineiro.power(c("AE"), null))
        assertTrue(Mineiro.power(c("7O"), null) > Mineiro.power(c("3P"), null))
        assertFalse(Mineiro.isManilha(c("4E"), null))
    }

    @Test fun playsCheapestCardThatBeatsTable() {
        val e = TrucoEngine(Paulista)
        val s = e.suggest(GameState(CardParser.parse("3P AE 4O"), c("5O"), c("2E")))
        assertEquals(c("3P"), s.card)
    }

    @Test fun discardsWeakestWhenNothingBeats() {
        val e = TrucoEngine(Paulista)
        val s = e.suggest(GameState(CardParser.parse("AE 4O 5C"), c("QO"), c("3E")))
        assertEquals(c("4O"), s.card)
    }

    @Test fun answersTrucoYesWithStrongHandAndNoWithWeak() {
        val e = TrucoEngine(Paulista)
        val strong = e.suggest(GameState(CardParser.parse("3P 3C 2E"), c("5O"), trucoCalled = true))
        assertTrue(strong.trucoAnswer!!.startsWith("SIM"))
        val weak = e.suggest(GameState(CardParser.parse("4O 5C 6E"), c("QO"), trucoCalled = true))
        assertTrue(weak.trucoAnswer!!.startsWith("NÃO"))
        assertNull(e.suggest(GameState(CardParser.parse("3P"), null)).trucoAnswer)
    }

    @Test fun parserIgnoresGarbage() {
        assertEquals(3, CardParser.parse("3P, 2c; ae xx").size)
    }
}
